"""
VibeScript: Where Code Meets Culture

A Gen Z-themed programming language that makes learning to code fun and accessible
by using familiar Gen Z slang and expressions as keywords.

This package contains the lexer, parser, and interpreter for the VibeScript language.
"""

__version__ = '0.1.0'
