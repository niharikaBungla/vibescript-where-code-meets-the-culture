# VibeScript: Where Code Meets Culture

VibeScript is a Gen Z-themed programming language designed to make coding more fun and accessible by using familiar slang and expressions as keywords.

## 🚀 Features

- **Gen Z-inspired Keywords**: Makes programming relatable and fun
- **Python-based Implementation**: Familiar semantics with a fresh syntax
- **Custom IDE**: Code, run, and debug all in one place
- **Error Handling**: Clear and helpful error messages
- **Example Programs**: Learn by example with provided sample code

## 📋 Language Reference

### Keywords

| VibeScript       | Traditional         | Description                     |
|------------------|--------------------|--------------------------------|
| `spill_the_tea`  | `print`            | Print to console                |
| `vibe_check`     | `input`            | Get user input                  |
| `no_cap`         | `if`               | If statement                    |
| `cap`            | `else`             | Else statement                  |
| `lowkey`         | `while`            | While loop                      |
| `highkey`        | `for`              | For loop                        |
| `rizz_up`        | `function`/`def`   | Define a function               |
| `slay`           | `return`           | Return from a function          |
| `lets_go`        | `{` or `:`         | Begin a block                   |
| `yeet`           | `}`                | End a block                     |
| `and_i_oop`      | `break`            | Break out of a loop             |
| `as_if`          | `continue`         | Skip to next iteration          |

### Data Types

| VibeScript     | Traditional     | Description                 |
|----------------|----------------|-----------------------------|
| `lit`          | `int`          | Integer                     |
| `tea`          | `string`       | String                      |
| `mood`         | `bool`         | Boolean                     |
| `stan`         | `list`/`array` | List/Array                  |
| `this_slaps`   | `true`         | Boolean true                |
| `im_dead`      | `false`        | Boolean false               |
| `ghost`        | `null`/`None`  | Null value                  |

## 🛠️ Installation & Setup

### Prerequisites

- Python 3.7 or higher
- Flask

### Getting Started

1. Clone this repository:
   ```
   git clone https://github.com/yourusername/vibescript.git
   cd vibescript
   